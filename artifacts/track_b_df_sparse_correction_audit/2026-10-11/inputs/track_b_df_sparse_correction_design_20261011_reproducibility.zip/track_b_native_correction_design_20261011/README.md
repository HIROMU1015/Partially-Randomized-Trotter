# Track B：DF少数軌道・希薄三次補正 — GPT設計自己検算

最初に `track_b_df_sparse_correction_design_review_20261011.md` を読んでください。
これは具体的な候補の数学的設計と、合成入力によるGPT自己検算です。Codexによる独立認証、native資源改善、分子結果を示すパッケージではありません。

## 内容

- `validate_design.py`：最終自己検算。Fractionによる形式語、8-mode/6-mode Fock恒等式、3-mode収束と反例control。
- `validation_results.json`：保存した全結果、seed、versions、source SHA256。
- `validation_stdout.txt`：最終実行の標準出力。
- `execution_history.json`：初期の二つのassertion failureと修正理由。raw tracebackは保存していないため、履歴は要約です。
- `history/validate_design_initial.py`：最初の検算script。既知のテストharness問題がある履歴であり、実行用の正本ではありません。
- `manifest.json`：同梱ファイルhash、取得したrepository sourceのidentityと読取範囲。

## 再実行

PythonとNumPy/SciPyが必要です。今回の実行環境は保存JSONに記録されています。

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python validate_design.py
```

Windows PowerShellでは環境変数を設定してから実行します。

```powershell
$env:OPENBLAS_NUM_THREADS="1"
$env:OMP_NUM_THREADS="1"
python validate_design.py
```

実行すると同じディレクトリの`validation_results.json`を再出力します。元の保存結果を残す場合は別コピーで実行してください。
浮動小数点残差はBLASやライブラリで多少変わり得ます。数式恒等式はFractionで評価します。

## 読み方の注意

最大6軌道への縮約は一つの三重交換子に対するoperator恒等式です。分子状態を6軌道へ近似したものではありません。
受理回数は確率から求めた期待値であり、実際に量子shotを生成した数ではありません。
P3 controlではこの有限δ範囲のslopeが約5に見えますが、exactなdegree-4残差が存在します。これをP3でも四次法になったという結果にしないでください。
中央unitaryのgate synthesisやcontrolled回路のコンパイルは未実装です。

旧repositoryのsource、結果、STOP、one-shot markerを変更・実行するコードは含みません。
