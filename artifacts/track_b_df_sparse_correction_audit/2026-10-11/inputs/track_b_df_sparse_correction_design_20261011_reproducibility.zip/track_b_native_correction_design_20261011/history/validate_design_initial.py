"""Independent exploratory checks for a proposed DF-native sparse cubic corrector.

No repository execution, chemistry provider, native compilation or quantum shots.
The formal checks use exact rational free-word arithmetic. Numerical checks use
small synthetic matrices only. These are not an independent Codex audit.
"""
from __future__ import annotations
import os
for _key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ.setdefault(_key, '1')
import json, math, platform, hashlib
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from collections import defaultdict
import numpy as np
import scipy
from scipy.linalg import expm, norm, qr

OUT=Path(__file__).resolve().parent
Poly=dict[tuple[int,...],F]

def add(*xs:Poly)->Poly:
    z=defaultdict(F)
    for x in xs:
        for w,a in x.items(): z[w]+=a
    return {w:a for w,a in z.items() if a}
def scale(x:Poly,a:F)->Poly:
    return {w:a*b for w,b in x.items() if a*b}
def mul(x:Poly,y:Poly,n:int=6)->Poly:
    z=defaultdict(F)
    for u,a in x.items():
        for v,b in y.items():
            if len(u)+len(v)<=n: z[u+v]+=a*b
    return {w:a for w,a in z.items() if a}
def comm(x:Poly,y:Poly,n:int=6)->Poly:
    return add(mul(x,y,n),scale(mul(y,x,n),F(-1)))
def exp_poly(x:Poly,n:int=6)->Poly:
    out={():F(1)}; power={():F(1)}
    for k in range(1,n+1):
        power=mul(power,x,n)
        if not power: break
        out=add(out,scale(power,F(1,math.factorial(k))))
    return out
def restrict(x:Poly,n:int)->Poly:
    return {w:a for w,a in x.items() if len(w)<=n}

def symbolic_checks():
    results=[]
    for m in (2,3,4):
        A=[{(j,):F(1)} for j in range(m)]
        S={():F(1)}
        for j in range(m-1): S=mul(S,exp_poly(scale(A[j],F(1,2))))
        S=mul(S,exp_poly(A[-1]))
        for j in reversed(range(m-1)): S=mul(S,exp_poly(scale(A[j],F(1,2))))
        L3={}
        for j in range(m-1):
            tail=add(*A[j+1:])
            L3=add(L3,scale(comm(A[j],comm(A[j],tail)),F(-1,24)),
                       scale(comm(tail,comm(A[j],tail)),F(-1,12)))
        U=exp_poly(add(*A))
        diff=add(S,scale(U,F(-1)))
        assert restrict(diff,2)=={}
        assert {w:a for w,a in diff.items() if len(w)==3}==L3
        C=exp_poly(scale(L3,F(-1,2)))
        cor=mul(mul(C,S),C)
        corrected_diff=add(cor,scale(U,F(-1)))
        assert restrict(corrected_diff,4)=={}
        reverse={w[::-1]:a for w,a in L3.items()}
        assert reverse==L3
        # Matrix-symbol dagger reverses a word and contributes (-1)^degree.
        Cwrong=exp_poly(scale(L3,F(1,2)))
        wrongdiff=add(mul(mul(Cwrong,S),Cwrong),scale(U,F(-1)))
        assert {w:a for w,a in wrongdiff.items() if len(w)==3}==scale(L3,F(2))
        results.append(dict(blocks=m,cubic_formula_exact=True,corrected_through_degree4=True,
             cubic_antihermitian_exact=True,wrong_sign_control_detected=True,
             fifth_order_nonzero_words=sum(len(w)==5 for w in corrected_diff),
             cubic_words=len(L3)))
    return results

def annihilators(n:int):
    out=[]
    for j in range(n):
        a=np.zeros((2**n,2**n),complex)
        for bit in range(2**n):
            if bit>>j&1:
                a[bit^(1<<j),bit]=(-1)**((bit&((1<<j)-1)).bit_count())
        out.append(a)
    return out

def involution(V:np.ndarray, sign:int=1):
    n=V.shape[0]; cs=annihilators(n); I=np.eye(2**n,dtype=complex)
    Q=I.copy()
    for v in V.T:
        a=sum(np.conj(v[j])*cs[j] for j in range(n))
        Q=Q@(I-2*a.conj().T@a)
    return sign*Q

def haar(n:int,rng):
    Q,R=np.linalg.qr(rng.normal(size=(n,n))+1j*rng.normal(size=(n,n)))
    ph=np.diag(R); return Q*(ph/abs(ph)).conj()

def exterior(W:np.ndarray):
    n=len(W); G=np.zeros((2**n,2**n),complex); G[0,0]=1
    for k in range(1,n+1):
        choices=list(combinations(range(n),k))
        for I in choices:
            ii=sum(1<<i for i in I)
            for J in choices:
                jj=sum(1<<j for j in J)
                G[ii,jj]=np.linalg.det(W[np.ix_(I,J)])
    return G

def cmat(A,B):return A@B-B@A

def support_check():
    rng=np.random.default_rng(20261011)
    n=8; r=6; W=haar(n,rng); B=W[:,:r]
    vs=[haar(r,rng)[:,:2] for _ in range(3)]
    qs=[involution(V,s) for V,s in zip(vs,(1,-1,1))]
    Qs=[involution(B@V,s) for V,s in zip(vs,(1,-1,1))]
    T=cmat(qs[0],cmat(qs[1],qs[2]))
    fullT=cmat(Qs[0],cmat(Qs[1],Qs[2]))
    G=exterior(W)
    lifted=G@np.kron(np.eye(2**(n-r)),T)@G.conj().T
    diff=norm(fullT-lifted,2)
    k=norm(T,2); kfull=norm(fullT,2)
    # Compare a full-system exponential to an active-six-mode exponential.
    theta=.07
    Ufull=expm(1j*theta*fullT/k)
    Ulift=G@np.kron(np.eye(2**(n-r)),expm(1j*theta*T/k))@G.conj().T
    udiff=norm(Ufull-Ulift,2)
    assert diff<2e-12 and abs(k-kfull)<2e-12 and udiff<2e-12
    assert k<=4+1e-12 and norm(T-T.conj().T,2)<2e-12
    # Independent isometry test of the Fock representation, including vacuum.
    assert norm(G.conj().T@G-np.eye(2**n),2)<2e-12
    return dict(system_modes=n,active_modes=r,local_dimension=2**r,
                support_residual=float(diff),norm_difference=float(abs(k-kfull)),
                commutator_norm=float(k),controlled_central_unitary_residual=float(udiff),
                exterior_unitary_residual=float(norm(G.conj().T@G-np.eye(2**n),2)))

def cubic_terms(blocks):
    terms=[]
    for j in range(len(blocks)-1):
        tail=[v for block in blocks[j+1:] for v in block]
        for ha,Qa in blocks[j]:
            for hb,Qb in blocks[j]:
                for hc,Qc in tail:
                    terms.append((ha*hb*hc/24,cmat(Qa,cmat(Qb,Qc))))
        for ha,Qa in tail:
            for hb,Qb in blocks[j]:
                for hc,Qc in tail:
                    terms.append((ha*hb*hc/12,cmat(Qa,cmat(Qb,Qc))))
    return terms

def taylor(H,delta,m):
    I=np.eye(len(H),dtype=complex); out=I.copy(); P=I.copy()
    for k in range(1,m+1):
        P=P@(-1j*delta*H)/k; out+=P
    return out

def step_matrix(Hs,delta,cutoff=None):
    S=np.eye(len(Hs[0]),dtype=complex)
    for H in Hs[:-1]: S=S@expm(-1j*delta*H/2)
    S=S@(expm(-1j*delta*Hs[-1]) if cutoff is None else taylor(Hs[-1],delta,cutoff))
    for H in reversed(Hs[:-1]): S=S@expm(-1j*delta*H/2)
    return S

def correction_mean(terms,delta,gamma,wrong_sign=False):
    dim=len(terms[0][1]); I=np.eye(dim,dtype=complex)
    A=sum(c for c,T in terms); B=4*A
    if B==0:return I,dict(B=0,Lambda=0,eta=0,theta=0,p_active=0)
    eta=min(1.,gamma*delta); theta=B*delta**3/(2*eta)
    M=I.copy(); Lambda=0.; K=np.zeros_like(I); p_total=0.
    for c,T in terms:
        k=norm(T,2); K+=c*T; Lambda+=c*k
        if k<1e-14: continue
        p=(c/A)*eta*k/4
        M+=p*(expm(((-1 if wrong_sign else 1)*1j*theta/k)*T)-I)
        p_total+=p
    C=expm(1j*delta**3*K/2)
    b=delta**6*(B*Lambda/eta+norm(K,2)**2)/8
    err=norm(M-C,2)
    assert err<=b+1e-13
    assert norm(M,2)<=1+1e-12 and p_total<=1+1e-12
    assert abs(p_total-eta*Lambda/B)<1e-13
    return M,dict(B=float(B),Lambda=float(Lambda),eta=eta,theta=float(theta),
        p_active=float(p_total),corrector_error=float(err),corrector_bound=float(b),
        K_norm=float(norm(K,2)))

def numerical_checks():
    rng=np.random.default_rng(740112)
    n=3
    qs=[involution(haar(n,rng)[:,:k],s) for k,s in [(1,1),(2,-1),(1,1)]]
    blocks=[[(.7,qs[0])],[(.5,qs[1])],[(.2,qs[2])]]
    Hs=[sum(h*Q for h,Q in block) for block in blocks]; H=sum(Hs)
    terms=cubic_terms(blocks); gamma=1.0; rows=[]
    for delta in (.2,.1,.05,.025,.0125):
        M,meta=correction_mean(terms,delta,gamma)
        U=expm(-1j*delta*H)
        raw=step_matrix(Hs,delta,5)
        corrected=M@raw@M
        p3=M@step_matrix(Hs,delta,3)@M
        W,_=correction_mean(terms,delta,gamma,True)
        wrong=W@raw@W
        t=1.; N=int(round(t/delta))
        globalerr=norm(np.linalg.matrix_power(corrected,N)-expm(-1j*t*H),2)
        rows.append(dict(delta=delta,uncorrected_p5_local=float(norm(raw-U,2)),
                        corrected_p5_local=float(norm(corrected-U,2)),
                        corrected_p3_local=float(norm(p3-U,2)),
                        wrong_sign_local=float(norm(wrong-U,2)),
                        corrected_p5_global=float(globalerr),
                        expected_active_per_trajectory=2*N*meta['p_active'],**meta))
    slopes={}
    for key in ('uncorrected_p5_local','corrected_p5_local','corrected_p3_local',
                'wrong_sign_local','corrected_p5_global'):
        slopes[key]=[math.log(rows[i][key]/rows[i+1][key],2) for i in range(len(rows)-1)]
    assert 4.8<slopes['corrected_p5_local'][-1]<5.2
    assert 3.8<slopes['corrected_p5_global'][-1]<4.2
    assert 2.8<slopes['uncorrected_p5_local'][-1]<3.2
    assert 3.8<slopes['corrected_p3_local'][-1]<4.2
    # Noncommuting pure D must still be corrected when R=0.
    pureblocks=[blocks[0],blocks[1],[(0.,qs[2])]]
    pterms=cubic_terms(pureblocks)
    pureK=sum(c*T for c,T in pterms)
    assert norm(pureK,2)>1e-5
    # All Q diagonal in same orbital frame: no cubic commutator.
    Iorb=np.eye(n)
    commblocks=[[(.7,involution(Iorb[:,:1]))],[(.5,involution(Iorb[:,1:2]))],
                [(.2,involution(Iorb[:,1:3]))]]
    assert all(norm(T,2)==0 for _,T in cubic_terms(commblocks))
    return dict(tuple_count=len(terms),rows=rows,slopes=slopes,
                pure_D_cubic_norm=float(norm(pureK,2)),all_commuting_zero=True)

if __name__=='__main__':
    data=dict(scope='Exploratory independent derivation checks; NOT native-resource evidence',
              seed_support=20261011,seed_convergence=740112,
              versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
              symbolic=symbolic_checks(),support=support_check(),numerical=numerical_checks())
    data['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (OUT/'validation_results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(data,ensure_ascii=False,indent=2))
