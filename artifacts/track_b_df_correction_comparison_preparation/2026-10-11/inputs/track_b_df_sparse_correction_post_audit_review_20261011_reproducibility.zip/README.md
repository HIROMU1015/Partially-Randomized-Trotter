# GPT post-audit scientific review reproducibility

Fixed source commit: `8a5e21c8f6ecf98ee285ec1fad49079ffb5ed97f`.

This archive contains the detailed Japanese scientific review and review-only checks. It does not contain molecular production results, quantum shots, compiled circuits, or new T-gate synthesis. The Codex 77 checks and 15 focused tests were NOT rerun.

Run `python review_checks.py` to reproduce the review-only calculations (NumPy, SciPy, SymPy required). Local r3/r6 matrices are reconstructed from the RNG recipe published in `audit_df_sparse_correction_native.py`; compilation fingerprints were not reproduced. Float Pauli coefficients/norms are diagnostics, not certified operational inputs.

`review_checks_initial.py` preserves the first passing version (17 checks). The final version adds the explicit coin-first second-moment check and extra explanatory fields, giving 18 passing checks. There were no failing self-checks in this run. Both versions remain in the archive.

No source repository was modified. No published paper full text or font is included. See the scientific review for source links, proof assumptions and literature-access limitations.
