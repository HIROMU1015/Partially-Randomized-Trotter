"""Review-only algebra checks. No repository runner, compiler, or molecular input.
Reference fixtures are reconstructed from the published native audit's RNG recipe.
New identities are checked independently; this is NOT a rerun of Codex's 77 tests.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'): os.environ[k]='1'
import json, hashlib, math, platform
from pathlib import Path
import numpy as np
import scipy
from scipy.linalg import expm, norm
import sympy as sp
OUT=Path(__file__).resolve().parent
REF='8a5e21c8f6ecf98ee285ec1fad49079ffb5ed97f'
checks=[]
def check(name, ok, details=None):
    checks.append({'name':name,'pass':bool(ok),'details':details})
    if not ok: raise AssertionError(name)
def comm(a,b):return a@b-b@a
def annihilators(n):
    ans=[]
    for k in range(n):
        a=np.zeros((2**n,2**n),complex)
        for s in range(2**n):
            if (s>>k)&1:a[s^(1<<k),s]=(-1)**((s&((1<<k)-1)).bit_count())
        ans.append(a)
    return ans
def second_q(h):
    aa=annihilators(len(h))
    return sum(h[i,j]*aa[i].conj().T@aa[j] for i in range(len(h)) for j in range(len(h)))
def parity_frame(v,sign=1):
    ans=sign*np.eye(2**len(v),dtype=complex)
    for col in v.T:ans=ans@(np.eye(len(ans))-2*second_q(np.outer(col,col.conj())))
    return ans
def unitary(n,rng):
    # This RNG recipe is explicitly taken from the published source, not a
    # claim of a fully independent random-fixture generator.
    q,r=np.linalg.qr(rng.standard_normal((n,n))+1j*rng.standard_normal((n,n)))
    return q*(np.diag(r)/abs(np.diag(r))).conjugate()
def fwht(a):
    v=np.array(a,dtype=complex,copy=True);h=1
    while h<len(v):
        for j in range(0,len(v),2*h):
            left=v[j:j+h].copy();right=v[j+h:j+2*h].copy()
            v[j:j+h]=left+right;v[j+h:j+2*h]=left-right
        h*=2
    return v
def pauli_coefficients(t):
    d=len(t); vals=np.zeros((d,d),complex); s=np.arange(d)
    for x in range(d):
        transform=fwht(t[s^x,s])/d
        for z in range(d):vals[x,z]=(-1j)**((x&z).bit_count())*transform[z]
    return vals
def rebuild(b):
    d=len(b);ans=np.zeros((d,d),complex)
    for x in range(d):
        for z in range(d):
            for s in range(d):ans[s^x,s]+=b[x,z]*(1j)**((x&z).bit_count())*(-1)**((z&s).bit_count())
    return ans
# Scalar symbolic test of the new leading attenuation and weighted-Pauli lift.
d,g,A,T=sp.symbols('d g A T', positive=True)
sparse=1-g*d+g*d*sp.exp(sp.I*A*d**2*T/(2*g))
series=sp.series(sparse,d,0,7).removeO().expand()
check('positive_sampler_delta5_coefficient',sp.simplify(series.coeff(d,5)+A*A*T*T/(8*g))==0)
check('positive_sampler_delta3_coefficient',sp.simplify(series.coeff(d,3)-sp.I*A*T/2)==0)
eta,h=sp.symbols('eta h', positive=True)
r=sp.sqrt(eta**2+h**2);mu=1-eta+r
check('weighted_identity_coefficient',sp.simplify((1-eta)+r*eta/r-1)==0)
check('weighted_Pauli_coefficient',sp.simplify(r*h/r-h)==0)
ell=sp.symbols('ell', positive=True)
mu_series=sp.series(1-g*d+sp.sqrt((g*d)**2+(A*ell*d**3/2)**2),d,0,7).removeO().expand()
check('weighted_mu_delta5_coefficient',sp.simplify(mu_series.coeff(d,5)-A*A*ell*ell/(8*g))==0)
x=sp.symbols('x',real=True)
B5=sp.sqrt(1+x*x)+x*x/2*sp.sqrt(1+x*x/9)+x**4/24*sp.sqrt(1+x*x/25)
logB5=sp.series(sp.log(B5),x,0,7)
check('RTE_logB5_leading_x2',sp.expand(logB5.removeO()).coeff(x,2)==1)
# Rank-one triple closure in quadratic fermionic algebra (independent fixture).
n=4;rng=np.random.default_rng(20261011)
cols=[unitary(n,rng)[:,0] for _ in range(3)]
Ps=[np.outer(v,v.conj()) for v in cols]
Qs=[np.eye(2**n)-2*second_q(p) for p in Ps]
Ta=comm(Qs[0],comm(Qs[1],Qs[2]))
h1=-8*comm(Ps[0],comm(Ps[1],Ps[2]))
closure_error=float(norm(Ta-second_q(h1),2))
check('rank_one_triple_is_quadratic',closure_error<1e-12,closure_error)
check('rank_one_unitary_is_Gaussian_generator',norm(expm(.012j*Ta)-expm(.012j*second_q(h1)),2)<1e-12)
# Reconstruct the two saved central E fixtures (no compile, no matching claim
# for the saved transpiled circuit fingerprint).
rng=np.random.default_rng(7101107);unitary(4,rng)
records=[]
for r in (3,6):
    frames=[unitary(r,rng)[:,:2] for _ in range(3)]
    qs=[parity_frame(v,s) for v,s in zip(frames,(1,-1,1))]
    t=comm(qs[0],comm(qs[1],qs[2]))
    b=pauli_coefficients(t)
    err=float(norm(rebuild(b)-t,2))
    check(f'r{r}.local_Pauli_reconstruction',err<1e-11,err)
    check(f'r{r}.Hermitian_Pauli_coefficients',np.max(np.abs(b.imag))<1e-12)
    check(f'r{r}.anticommutes_outer_involution',norm(qs[0]@t+t@qs[0],2)<1e-11)
    ellval=float(np.abs(b).sum());normval=float(norm(t,2))
    u=.03125/4
    ell_real=float(np.abs(b.real).sum())
    # Verify weighted Pauli mixture algebra using the full nonthresholded real
    # coefficients, including all near-zero coefficients.
    hval=.1*u*ell_real;etaval=.1
    rv=math.hypot(etaval,hval);muv=1-etaval+rv
    angle=math.atan2(hval,etaval)
    weighted=(1-etaval)*np.eye(len(t))+rv*(math.cos(angle)*np.eye(len(t))+1j*math.sin(angle)*rebuild(b.real)/ell_real)
    target=np.eye(len(t))+1j*.1*u*t
    check(f'r{r}.weighted_Pauli_mean',norm(weighted-target,2)<1e-11)
    record={'active_modes':r,'T_norm_float_diagnostic':normval,'local_Pauli_l1_float_diagnostic':ellval,
      'Pauli_reconstruction_residual':err,'Pauli_nonzero_at_1e_12_DIAGNOSTIC_NOT_DROPPED':int((np.abs(b)>1e-12).sum()),
      'source_theta':.03125,'source_kappa':4,'u':u,
      'conditional_pairing_mass_sqrt_1_plus_uell_squared':math.sqrt(1+(u*ellval)**2),
      'max_single_controlled_Pauli_CX_parity_ladder_ideal_upper':2*r,
      'not_total_algorithm_cost':True,'no_native_synthesis_or_quantum_execution':True,
      'outer_coin_eta_diagnostic':etaval,
      'outer_coin_weight_second_moment':1+etaval*(u*ell_real)**2,
      'outer_coin_rotation_probability':etaval,
      'warning':'Pairing mass is a weight on an accepted branch, not the whole-trajectory normalization.'}
    records.append(record)
    np.savez_compressed(OUT/f'local_r{r}_reconstruction.npz',T=t,coeff=b)
# Exact second-moment formula for the implementable coin-first comparator.
q,w = sp.symbols('q w', positive=True)
check('coin_first_weight_second_moment',sp.expand((1-q)+q*(1+w*w)-(1+q*w*w))==0)
# Direct cancellation diagnostic: K=0 does not force sampler attenuation zero.
Z=np.diag([1.,-1.]);eps=.07;et=.1
mean=(1-et)*np.eye(2)+et/2*(expm(1j*eps*Z)+expm(-1j*eps*Z))
check('zero_sum_K_still_attenuates',norm(mean-np.eye(2),2)>0)
res={'kind':'GPT_POST_AUDIT_REVIEW_SELF_CHECKS_NOT_SCIENCE_PRODUCTION','date_JST':'2026-10-11',
 'fixed_reference':REF,'symbolic_positive_series':str(series),'symbolic_log_B5':str(logB5),
 'rank_one_closure_residual':closure_error,'reconstructed_saved_source_fixtures':records,
 'checks':checks,'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),
 'production_or_molecular_runs':0,'native_compilations':0,'Clifford_T_synthesis':0,
 'Codex_77_tests_rerun':False,'runtime':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__},
 'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'scope_caveat':'Scalar identities and small operator diagnostics only. Float Pauli norms are not certified operational inputs. Source fixture reconstruction is not an independent reproduction of compilation counts.'}
(OUT/'review_checks.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(res,ensure_ascii=False,indent=2))
