# A1 N3 B campaign

Campaign: A1-N3-B-H4-m0-q1-20261106-run01

Status: STOPPED

Reason: {"type": "SystemExit", "message": "143"}

All durable worker tails are authoritative; see ACCOUNTING.json, CALL_COUNTS.json and ATTEMPTS.json.
Incomplete comparisons carry no precision or CV improvement claim. Expected cost improvement is UNKNOWN.
Mandatory STOP for this attempt; technical recovery authorized, scientific gates unchanged.
