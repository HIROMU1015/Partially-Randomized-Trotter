Windows PowerShell/cmd; Python 3.11+. Existing SSH aliases qg1/qg2.
Relay fix: 25575ce0f3b43396144c768e9f7dab7dc193beab
Controller and worker fixed SOURCE: 4ae47cf4844638647c83ea898ee53588675b0d75
Stop the previous relay before replacing files. Keep its state directory and all worker spools.
From this directory:
py -3 -B scripts\setup_rpe_q3_mailbox.py --config relay.json --profile server1.profile.json
Only after ok=true: py -3 -B scripts\run_rpe_q3_relay.py --config relay.json --start
py -3 -B scripts\run_rpe_q3_relay.py --config relay.json --status
py -3 -B scripts\run_rpe_q3_relay.py --config relay.json --stop
Received jobs keep running when the relay stops.
