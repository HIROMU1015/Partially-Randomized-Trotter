Windows PowerShell/cmd, Python 3.11+: existing qg1/qg2 SSH aliases.
Run from this extracted directory:
py -3 scripts\run_rpe_q3_relay.py --config relay.json --start
py -3 scripts\run_rpe_q3_relay.py --config relay.json --status
py -3 scripts\run_rpe_q3_relay.py --config relay.json --stop
After stopped_epoch: rerun --start with the same relay.json and state directory.
Received server1 jobs keep running when this relay stops.
