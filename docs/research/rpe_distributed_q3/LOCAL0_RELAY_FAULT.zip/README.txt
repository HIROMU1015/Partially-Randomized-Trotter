Controlled ARTIFICIAL fault acceptance only: two jobs, 12s artificial delay.
Computation SOURCE 1ffdf610a682a23e2a0a388b570d33d0f353fedc
Relay/tools SOURCE 28d976b99cdf8329adcc1b79327e329e947ef774
Stop previous relays, setup this profile, start, stop after 8s, inspect RUNNING, wait 15s, inspect completion, upload snapshots, restart.
Full reproducible PowerShell commands are in HANDOFF.md.
Inspector is read-only and never starts ASSIGNED work.
