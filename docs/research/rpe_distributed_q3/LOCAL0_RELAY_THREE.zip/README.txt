Fixed controller/workers/relay: 1ffdf610a682a23e2a0a388b570d33d0f353fedc
Old two-host run and spools remain separate.
Use setup helper with --source 1ffdf610a682a23e2a0a388b570d33d0f353fedc for both workers.
RomuTail repository: /home/abe/Project/Partially Randomized Trotter
Start relay only after both setup commands report ok=true.
