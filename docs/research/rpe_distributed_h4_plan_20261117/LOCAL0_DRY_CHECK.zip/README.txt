READINESS ONLY. Follow LOCAL0_DRY_CHECK.md. No relay/controller/queue/mailbox/execute/collect. Every adapter call explicitly uses --mode dry-check.
